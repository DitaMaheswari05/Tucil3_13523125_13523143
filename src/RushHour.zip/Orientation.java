public enum Orientation {
    HORIZONTAL,
    VERTICAL
}